# Laravel Manual Approval Wiring — Patch Summary

**Added**
- `backend/app/Http/Controllers/Api/AdminApprovalController.php`
- `backend/app/Http/Middleware/AdminMiddleware.php`

**Updated**
- `backend/app/Http/Controllers/Api/TransactionController.php` — creates `AdminApproval` records on invest/withdraw.
- `backend/routes/api.php` — new admin approvals endpoints.

**Manual step required**
- Register middleware alias in `backend/app/Http/Kernel.php`:

```php
protected $routeMiddleware = [
    // ...
    'admin' => \App\Http\Middleware\AdminMiddleware::class,
];
```

**Migrate & test**

```bash
# backend/
php artisan migrate

# Serve API
php artisan serve --host=0.0.0.0 --port=8000

# Test approvals (as admin user)
curl -s http://localhost:8000/api/admin-approvals | jq .
```

**Frontend (Next.js)**
- Switch to Laravel auth provider in `src/app/layout.tsx`:
```ts
// import { AuthProvider } from '@/hooks/useAuth'
import { AuthProvider } from '@/hooks/useAuth-laravel'
```
- Set `NEXT_PUBLIC_LARAVEL_API_URL` in `.env`:
```
NEXT_PUBLIC_LARAVEL_API_URL=http://localhost:8000/api
```

