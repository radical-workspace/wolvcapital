<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AdminApproval;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class AdminApprovalController extends Controller
{
    /**
     * List approvals (admin).
     */
    public function index(Request $request): JsonResponse
    {
        $this->authorizeAdmin($request);

        $query = AdminApproval::query()->latest();
        if ($status = $request->query('status')) {
            $query->where('status', $status);
        }
        if ($type = $request->query('approval_type')) {
            $query->where('approval_type', $type);
        }
        return response()->json([
            'items' => $query->paginate(20)
        ]);
    }

    /**
     * Show one approval (admin).
     */
    public function show(Request $request, string $id): JsonResponse
    {
        $this->authorizeAdmin($request);
        $approval = AdminApproval::findOrFail($id);
        return response()->json([ 'item' => $approval ]);
    }

    /**
     * Approve a request.
     */
    public function approve(Request $request, string $id): JsonResponse
    {
        $this->authorizeAdmin($request);
        $approval = AdminApproval::findOrFail($id);
        if ($approval->isApproved()) {
            return response()->json(['message' => 'Already approved'], 200);
        }
        $approval->status = 'approved';
        $approval->decision_notes = $request->input('decision_notes');
        $approval->save();

        return response()->json(['message' => 'Approved', 'item' => $approval]);
    }

    /**
     * Reject a request.
     */
    public function reject(Request $request, string $id): JsonResponse
    {
        $this->authorizeAdmin($request);
        $approval = AdminApproval::findOrFail($id);
        if ($approval->isRejected()) {
            return response()->json(['message' => 'Already rejected'], 200);
        }
        $approval->status = 'rejected';
        $approval->decision_notes = $request->input('decision_notes');
        $approval->save();

        return response()->json(['message' => 'Rejected', 'item' => $approval]);
    }

    protected function authorizeAdmin(Request $request): void
    {
        $user = $request->user();
        if (!$user || $user->role !== 'admin') {
            abort(403, 'Admin only');
        }
    }
}
